import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String[] sen = null;
        System.out.println("Are you translating from Spanish to English, or English to Spanish?");
        String t = s.nextLine();
        System.out.println("What do you want translated?");
        String sent = s.nextLine();
        sen = sent.split(" ");
        if(t.equals("english to spanish") || t.equals("English to Spanish")){
            englisht eng = new englisht();
            eng.english(sen);
        }
        if(t.equals("spanish to english") || t.equals("Spanish to English")){
            spanisht span = new spanisht();
            span.spanish(sen);
        }
    }
}