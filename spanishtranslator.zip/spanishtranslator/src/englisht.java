class englisht {
    public void english(String[] sen) {
        for (int i = 0; i < sen.length; i++) {
            if (sen[i].contains("I")) {
                System.out.print("yo" + "\t");
            }
            if (sen[i].contains("as") || sen[i].contains("how")) {
                System.out.print("como" + "\t");
            }
            if (sen[i].contains("his") || sen[i].contains("their")) {
                System.out.print("su" + "\t");
            }
            if (sen[i].contains("that") || sen[i].contains("which")) {
                System.out.print("que" + "\t");
            }
            if (sen[i].contains("he")) {
                System.out.print("el" + "\t");
            }
            if (sen[i].contains("was")) {
                System.out.print("era" + "\t");
            }
            if (sen[i].contains("for")) {
                System.out.print("para" + "\t");
            }
            if (sen[i].contains(" in ") || sen[i].contains(" on ") || sen[i].contains(" at ")) {
                System.out.print("en" + "\t");
            }
            if (sen[i].contains(" are ")) {
                System.out.print("son" + "\t");
            }
            if (sen[i].contains(" with ")) {
                System.out.print("con" + "\t");
            }
            if (sen[i].contains("they")) {
                System.out.print("ellos" + "\t");
            }
            if (sen[i].contains(" be ")) {
                System.out.print("ser" + "\t");
            }
            if (sen[i].contains("one")) {
                System.out.print("uno" + "\t");
            }
            if (sen[i].contains("have")) {
                System.out.print("tener" + "\t");
            }
            if (sen[i].contains("this")) {
                System.out.print("este" + "\t");
            }
            if (sen[i].contains("from")) {
                System.out.print("desde" + "\t");
            }
            if (sen[i].contains(" by ")) {
                System.out.print("por" + "\t");
            }
            if (sen[i].contains("hot")) {
                System.out.print("caliente" + "\t");
            }
            if (sen[i].contains("word")) {
                System.out.print("palabras" + "\t");
            }
            if (sen[i].contains("but")) {
                System.out.print("pero" + "\t");
            }
            if (sen[i].contains("what")) {
                System.out.print("que" + "\t");
            }
            if (sen[i].contains("some")) {
                System.out.print("algunos" + "\t");
            }
            if (sen[i].contains(" is ")) {
                System.out.print("es" + "\t");
            }
            if (sen[i].contains("it")) {
                System.out.print("lo" + "\t");
            }
            if (sen[i].contains("you")) {
                System.out.print("usted" + "\t");
            }
            if (sen[i].contains("had")) {
                System.out.println("tiendo" + "\t");
            }
            if (sen[i].contains("the")) {
                System.out.print("la" + "\t");
            }
            if (sen[i].contains(" of ")) {
                System.out.print("de" + "\t");
            }
            if (sen[i].contains(" or ")) {
                System.out.print("o" + "\t");
            }
            if (sen[i].contains(" to ")) {
                System.out.print("a" + "\t");
            }
            if (sen[i].contains(" and ")) {
                System.out.print("y" + "\t");
            }
            if (sen[i].contains(" a ")) {
                System.out.print("un" + "\t");
            }
            if (sen[i].contains(" we ")) {
                System.out.print("nos" + "\t");
            }
            if (sen[i].contains("can")) {
                System.out.print("lata" + "\t");
            }
            if (sen[i].contains(" out ")) {
                System.out.print("fuera" + "\t");
            }
            if (sen[i].contains(" other ")) {
                System.out.print("otros" + "\t");
            }
            if (sen[i].contains(" were ")) {
                System.out.print("eran" + "\t");
            }
            if (sen[i].contains(" do ") || sen[i].contains("does")) {
                System.out.print("hacer" + "\t");
            }
            if (sen[i].contains("time") || sen[i].contains("temperature")) {
                System.out.print("tiempo" + "\t");
            }
            if (sen[i].contains(" yes ") || sen[i].contains(" if ")) {
                System.out.print("si" + "\t");
            }
            if (sen[i].contains(" will ")) {
                System.out.println("lo hara" + "\t");
            }
            if (sen[i].contains("said")) {
                System.out.println("dicho" + "\t");
            }
            if (sen[i].contains("each")) {
                System.out.println("cada" + "\t");
            }
            if (sen[i].contains("tell")) {
                System.out.println("decir" + "\t");
            }
            if (sen[i].contains(" set ")) {
                System.out.println("conjunto" + "\t");
            }
            if (sen[i].contains("three")) {
                System.out.println("tres" + "\t");
            }
            if (sen[i].contains(" want ")) {
                System.out.println("querer" + "\t");
            }
            if (sen[i].contains(" air ")) {
                System.out.println("aire" + "\t");
            }
            if (sen[i].contains(" well ")) {
                System.out.println("asi" + "\t");
            }
            if (sen[i].contains("also")) {
                System.out.println("tambien" + "\t");
            }
            if (sen[i].contains("play")) {
                System.out.println("jugar" + "\t");
            }
            if (sen[i].contains("small")) {
                System.out.print("pequeno" + "\t");
            }
            if (sen[i].contains("end")) {
                System.out.print("fin" + "\t");
            }
            if (sen[i].contains(" put ")) {
                System.out.print("poner" + "\t");
            }
            if (sen[i].contains("read")) {
                System.out.print("leer" + "\t");
            }
            if (sen[i].contains(" hand ")) {
                System.out.print("mano" + "\t");
            }
            if (sen[i].contains(" port ")) {
                System.out.print("puerto" + "\t");
            }
            if (sen[i].contains("large") || sen[i].contains("big")) {
                System.out.print("grande" + "\t");
            }
            if (sen[i].contains(" spell ")) {
                System.out.print("deletrear" + "\t");
            }
            if (sen[i].contains(" add ")) {
                System.out.print("andir" + "\t");
            }
            if (sen[i].contains("even")) {
                System.out.print("incluso" + "\t");
            }
            if (sen[i].contains("land") || sen[i].contains("Earth")) {
                System.out.print("tierra" + "\t");
            }
            if (sen[i].contains("here")) {
                System.out.print("aqui" + "\t");
            }
            if (sen[i].contains("must")) {
                System.out.print("debe" + "\t");
            }
            if (sen[i].contains("tall") || sen[i].contains("high")) {
                System.out.print("alto" + "\t");
            }
            if (sen[i].contains("such")) {
                System.out.print("tal" + "\t");
            }
            if (sen[i].contains("follow")) {
                System.out.print("siga" + "\t");
            }
            if (sen[i].contains("act")) {
                System.out.print("acto" + "\t");
            }
            if (sen[i].contains("why")) {
                System.out.print("por que" + "\t");
            }
            if (sen[i].contains("ask")) {
                System.out.print("preguntar" + "\t");
            }
            if (sen[i].contains(" men ")) {
                System.out.print("hombres" + "\t");
            }
            if (sen[i].contains("change")) {
                System.out.print("cambio" + "\t");
            }
            if (sen[i].contains("went")) {
                System.out.print("se fue" + "\t");
            }
            if (sen[i].contains(" light ")) {
                System.out.print("luz" + "\t");
            }
            if (sen[i].contains("kind")) {
                System.out.print("tipo" + "\t");
            }
            if (sen[i].contains("off")) {
                System.out.print("fuera" + "\t");
            }
            if (sen[i].contains("need")) {
                System.out.print("necesitara" + "\t");
            }
            if (sen[i].contains("house")) {
                System.out.print("casa" + "\t");
            }
            if (sen[i].contains("picture")) {
                System.out.print("imagen" + "\t");
            }
            if (sen[i].contains(" try ")) {
                System.out.print("tratar" + "\t");
            }
            if (sen[i].contains(" us ")) {
                System.out.print("nos" + "\t");
            }
            if (sen[i].contains(" again ")) {
                System.out.print("de nuevo" + "\t");
            }
            if (sen[i].contains("animal")) {
                System.out.print("animal" + "\t");
            }
            if (sen[i].contains(" point ")) {
                System.out.print("punto" + "\t");
            }
            if (sen[i].contains(" mother ")) {
                System.out.print("madre" + "\t");
            }
            if (sen[i].contains(" world ")) {
                System.out.print("mundo" + "\t");
            }
            if (sen[i].contains(" near ")) {
                System.out.print("cerca" + "\t");
            }
            if (sen[i].contains(" build ")) {
                System.out.print("constructir" + "\t");
            }
            if (sen[i].contains(" self ")) {
                System.out.print("auto" + "\t");
            }
            if (sen[i].contains(" father ")) {
                System.out.print("padre" + "\t");
            }
            if (sen[i].contains(" any ")) {
                System.out.print("cualquier" + "\t");
            }
            if (sen[i].contains(" new ")) {
                System.out.print("nuevo" + "\t");
            }
            if (sen[i].contains(" work ")) {
                System.out.print("trabajo" + "\t");
            }
            if (sen[i].contains(" part ")) {
                System.out.print("parte" + "\t");
            }
            if (sen[i].contains(" take ")) {
                System.out.print("tomar" + "\t");
            }
            if (sen[i].contains(" get ")) {
                System.out.print("conseguir" + "\t");
            }
            if (sen[i].contains(" place ")) {
                System.out.print("lugar" + "\t");
            }
            if (sen[i].contains(" made ")) {
                System.out.print("hecho" + "\t");
            }
            if (sen[i].contains(" live ")) {
                System.out.print("vivir" + "\t");
            }
            if (sen[i].contains(" where ")) {
                System.out.print("donde" + "\t");
            }
            if (sen[i].contains("after")) {
                System.out.print("despues" + "\t");
            }
            if (sen[i].contains("back")) {
                System.out.print("espalda" + "\t");
            }
            if (sen[i].contains("little")) {
                System.out.print("poco" + "\t");
            }
            if (sen[i].contains("only") || (sen[i].contains("just"))) {
                System.out.print("solo" + "\t");
            }
            if (sen[i].contains(" round ")) {
                System.out.print("ronda" + "\t");
            }
            if (sen[i].contains("year")) {
                System.out.print("anos" + "\t");
            }
            if (sen[i].contains(" came ")) {
                System.out.print("vino" + "\t");
            }
            if (sen[i].contains("show")) {
                System.out.print("show" + "\t");
            }
            if (sen[i].contains(" every ")) {
                System.out.print("cada" + "\t");
            }
            if (sen[i].contains(" good ")) {
                System.out.print("buena" + "\t");
            }
            if (sen[i].contains(" me ")) {
                System.out.print("me" + "\t");
            }
            if (sen[i].contains("give")) {
                System.out.print("dar" + "\t");
            }
            if (sen[i].contains(" our ")) {
                System.out.print("nuestro" + "\t");
            }
            if (sen[i].contains(" under ") || (sen[i].contains("short") || sen[i].contains(" low "))) {
                System.out.print("bajo" + "\t");
            }
            if (sen[i].contains("name")) {
                System.out.print("nombre" + "\t");
            }
            if (sen[i].contains(" very ")) {
                System.out.print("muy" + "\t");
            }
            if (sen[i].contains("through")) {
                System.out.print("a traves de" + "\t");
            }
            if (sen[i].contains(" form ")) {
                System.out.print("forma" + "\t");
            }
            if (sen[i].contains("sentence")) {
                System.out.print("frase" + "\t");
            }
            if (sen[i].contains("great")) {
                System.out.print("gran" + "\t");
            }
            if (sen[i].contains(" think ")) {
                System.out.print("pensar" + "\t");
            }
            if (sen[i].contains(" say ")) {
                System.out.print("decir" + "\t");
            }
            if (sen[i].contains("help")) {
                System.out.print("ayudar" + "\t");
            }
            if (sen[i].contains("line")) {
                System.out.print("linea" + "\t");
            }
            if (sen[i].contains("cause")) {
                System.out.print("causa" + "\t");
            }
            if (sen[i].contains("much")) {
                System.out.print("mucho" + "\t");
            }
            if (sen[i].contains("bring")) {
                System.out.print("traer" + "\t");
            }
            if (sen[i].contains("homework")) {
                System.out.print("tarea" + "\t");
            }
            if (sen[i].contains(" class ")) {
                System.out.print("clase" + "\t");
            }
            if (sen[i].contains(" today ")) {
                System.out.print("hoy" + "\t");
            }
            if (sen[i].contains("school")) {
                System.out.println("escuela" + "\t");
            }
        }
    }
}
