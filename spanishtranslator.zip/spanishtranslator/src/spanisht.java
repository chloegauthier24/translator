import java.util.Scanner;
class spanisht {
    public void spanish(String[] sen) {
        for (int i = 0; i < sen.length; i++) {
            if (sen[i].contains("yo")) {
                System.out.print("I" + "\t");
            }
            if (sen[i].contains("como")) {
                System.out.print("as/how" + "\t");
            }
            if (sen[i].contains("su")) {
                System.out.print("his/their" + "\t");
            }
            if (sen[i].contains("que")) {
                System.out.print("that/which" + "\t");
            }
            if (sen[i].contains("el")) {
                System.out.print("he" + "\t");
            }
            if (sen[i].contains("era")) {
                System.out.print("was" + "\t");
            }
            if (sen[i].contains("para")) {
                System.out.print("for" + "\t");
            }
            if (sen[i].contains(" en ")) {
                System.out.print("in/on/at" + "\t");
            }
            if (sen[i].contains("son")) {
                System.out.print("are" + "\t");
            }
            if (sen[i].contains("con")) {
                System.out.print("with" + "\t");
            }
            if (sen[i].contains("ellos")) {
                System.out.print("they" + "\t");
            }
            if (sen[i].contains("ser")) {
                System.out.print("be" + "\t");
            }
            if (sen[i].contains("uno")) {
                System.out.print("one" + "\t");
            }
            if (sen[i].contains("tener")) {
                System.out.print("have" + "\t");
            }
            if (sen[i].contains("este")) {
                System.out.print("this" + "\t");
            }
            if (sen[i].contains("desde")) {
                System.out.print("from" + "\t");
            }
            if (sen[i].contains("por")) {
                System.out.print("by" + "\t");
            }
            if (sen[i].contains("caliente")) {
                System.out.print("hot" + "\t");
            }
            if (sen[i].contains("palabra")) {
                System.out.print("word" + "\t");
            }
            if (sen[i].contains("pero")) {
                System.out.print("but" + "\t");
            }
            if (sen[i].contains("que")) {
                System.out.print("what" + "\t");
            }
            if (sen[i].contains("algunos")) {
                System.out.print("some" + "\t");
            }
            if (sen[i].contains("es")) {
                System.out.print("is" + "\t");
            }
            if (sen[i].contains("lo")) {
                System.out.print("it" + "\t");
            }
            if (sen[i].contains("usted")) {
                System.out.print("you" + "\t");
            }
            if (sen[i].contains("tenido")) {
                System.out.println("had" + "\t");
            }
            if (sen[i].contains("la")) {
                System.out.print("the" + "\t");
            }
            if (sen[i].contains("de ")) {
                System.out.print("of" + "\t");
            }
            if (sen[i].contains(" o ")) {
                System.out.print("or" + "\t");
            }
            if (sen[i].contains(" a ")) {
                System.out.print("to" + "\t");
            }
            if (sen[i].contains(" y ")) {
                System.out.print("and" + "\t");
            }
            if (sen[i].contains(" un ")) {
                System.out.print("a/an" + "\t");
            }
            if (sen[i].contains("nos")) {
                System.out.print("we" + "\t");
            }
            if (sen[i].contains("lata")) {
                System.out.print("can" + "\t");
            }
            if (sen[i].contains("fuera")) {
                System.out.print("out" + "\t");
            }
            if (sen[i].contains(" otros ")) {
                System.out.print("other" + "\t");
            }
            if (sen[i].contains(" eran ")) {
                System.out.print("were" + "\t");
            }
            if (sen[i].contains("hacer")) {
                System.out.print("do/does" + "\t");
            }
            if (sen[i].contains("tiempo")) {
                System.out.print("time/temperature" + "\t");
            }
            if (sen[i].contains(" si ")) {
                System.out.print("yes/if" + "\t");
            }
            if (sen[i].contains("lo hara")) {
                System.out.println("will" + "\t");
            }
            if (sen[i].contains("dicho")) {
                System.out.println("said" + "\t");
            }
            if (sen[i].contains("cada")) {
                System.out.println("each" + "\t");
            }
            if (sen[i].contains("decir")) {
                System.out.println("tell" + "\t");
            }
            if (sen[i].contains("conjunto")) {
                System.out.println("set" + "\t");
            }
            if (sen[i].contains("tres")) {
                System.out.println("three" + "\t");
            }
            if (sen[i].contains("querer")) {
                System.out.println("want" + "\t");
            }
            if (sen[i].contains("aire")) {
                System.out.println("air" + "\t");
            }
            if (sen[i].contains("asi")) {
                System.out.println("well" + "\t");
            }
            if (sen[i].contains("tambien")) {
                System.out.println("also" + "\t");
            }
            if (sen[i].contains("jugar")) {
                System.out.println("play" + "\t");
            }
            if (sen[i].contains("pequeno")) {
                System.out.print("small" + "\t");
            }
            if (sen[i].contains("fin")) {
                System.out.print("end" + "\t");
            }
            if (sen[i].contains("poner")) {
                System.out.print("put" + "\t");
            }
            if (sen[i].contains("leer")) {
                System.out.print("read" + "\t");
            }
            if (sen[i].contains("mano")) {
                System.out.print("hand" + "\t");
            }
            if (sen[i].contains("puerto")) {
                System.out.print("port" + "\t");
            }
            if (sen[i].contains("grande")) {
                System.out.print("large/big" + "\t");
            }
            if (sen[i].contains("deletrear")) {
                System.out.print("spell" + "\t");
            }
            if (sen[i].contains("anadir")) {
                System.out.print("add" + "\t");
            }
            if (sen[i].contains("incluso")) {
                System.out.print("even" + "\t");
            }
            if (sen[i].contains("tierra")) {
                System.out.print("land/Earth" + "\t");
            }
            if (sen[i].contains("aqui")) {
                System.out.print("here" + "\t");
            }
            if (sen[i].contains("debe")) {
                System.out.print("must" + "\t");
            }
            if (sen[i].contains("alto")) {
                System.out.print("tall/high" + "\t");
            }
            if (sen[i].contains("tal")) {
                System.out.print("such" + "\t");
            }
            if (sen[i].contains("siga")) {
                System.out.print("follow" + "\t");
            }
            if (sen[i].contains("acto")) {
                System.out.print("act" + "\t");
            }
            if (sen[i].contains("por que")) {
                System.out.print("why" + "\t");
            }
            if (sen[i].contains("preguntar")) {
                System.out.print("ask" + "\t");
            }
            if (sen[i].contains("hombres")) {
                System.out.print("men" + "\t");
            }
            if (sen[i].contains("cambio")) {
                System.out.print("change" + "\t");
            }
            if (sen[i].contains("se fue")) {
                System.out.print("went" + "\t");
            }
            if (sen[i].contains("luz")) {
                System.out.print("light" + "\t");
            }
            if (sen[i].contains("tipo")) {
                System.out.print("kind" + "\t");
            }
            if (sen[i].contains("fuera")) {
                System.out.print("off" + "\t");
            }
            if (sen[i].contains("necesitara")) {
                System.out.print("need" + "\t");
            }
            if (sen[i].contains("casa")) {
                System.out.print("house" + "\t");
            }
            if (sen[i].contains("imagen")) {
                System.out.print("picture" + "\t");
            }
            if (sen[i].contains("tratar")) {
                System.out.print("try" + "\t");
            }
            if (sen[i].contains(" nos ")) {
                System.out.print("us" + "\t");
            }
            if (sen[i].contains("de nuevo")) {
                System.out.print("again" + "\t");
            }
            if (sen[i].contains("animal")) {
                System.out.print("animal" + "\t");
            }
            if (sen[i].contains("punto")) {
                System.out.print("point" + "\t");
            }
            if (sen[i].contains("madre")) {
                System.out.print("mother" + "\t");
            }
            if (sen[i].contains("mundo")) {
                System.out.print("world" + "\t");
            }
            if (sen[i].contains("cerca")) {
                System.out.print("near" + "\t");
            }
            if (sen[i].contains("construir")) {
                System.out.print("build" + "\t");
            }
            if (sen[i].contains(" auto ")) {
                System.out.print("self" + "\t");
            }
            if (sen[i].contains("padre")) {
                System.out.print("father" + "\t");
            }
            if (sen[i].contains("cualquier")) {
                System.out.print("any" + "\t");
            }
            if (sen[i].contains(" nuevo ")) {
                System.out.print("new" + "\t");
            }
            if (sen[i].contains("trabajo")) {
                System.out.print("work" + "\t");
            }
            if (sen[i].contains("parte")) {
                System.out.print("part" + "\t");
            }
            if (sen[i].contains("tomar")) {
                System.out.print("take" + "\t");
            }
            if (sen[i].contains("conseguir")) {
                System.out.print("get" + "\t");
            }
            if (sen[i].contains("lugar")) {
                System.out.print("place" + "\t");
            }
            if (sen[i].contains("hecho")) {
                System.out.print("made" + "\t");
            }
            if (sen[i].contains("vivir")) {
                System.out.print("live" + "\t");
            }
            if (sen[i].contains("donde")) {
                System.out.print("where" + "\t");
            }
            if (sen[i].contains("despues")) {
                System.out.print("after" + "\t");
            }
            if (sen[i].contains("espalda")) {
                System.out.print("back" + "\t");
            }
            if (sen[i].contains("poco")) {
                System.out.print("little" + "\t");
            }
            if (sen[i].contains(" solo ")) {
                System.out.print("only/just" + "\t");
            }
            if (sen[i].contains("ronda")) {
                System.out.print("round" + "\t");
            }
            if (sen[i].contains("anos")) {
                System.out.print("year" + "\t");
            }
            if (sen[i].contains("vino")) {
                System.out.print("came" + "\t");
            }
            if (sen[i].contains("show")) {
                System.out.print("show" + "\t");
            }
            if (sen[i].contains("cada")) {
                System.out.print("every" + "\t");
            }
            if (sen[i].contains("buena")) {
                System.out.print("good" + "\t");
            }
            if (sen[i].contains("me")) {
                System.out.print("my" + "\t");
            }
            if (sen[i].contains("dar")) {
                System.out.print("give" + "\t");
            }
            if (sen[i].contains("nuestro")) {
                System.out.print("our" + "\t");
            }
            if (sen[i].contains("bajo")) {
                System.out.print("under/short/low" + "\t");
            }
            if (sen[i].contains("nombre")) {
                System.out.print("name" + "\t");
            }
            if (sen[i].contains("muy")) {
                System.out.print("very" + "\t");
            }
            if (sen[i].contains("a traves de")) {
                System.out.print("through" + "\t");
            }
            if (sen[i].contains("forma")) {
                System.out.print("form" + "\t");
            }
            if (sen[i].contains("frase")) {
                System.out.print("sentence" + "\t");
            }
            if (sen[i].contains("gran")) {
                System.out.print("great" + "\t");
            }
            if (sen[i].contains("pensar")) {
                System.out.print("think" + "\t");
            }
            if (sen[i].contains("decir")) {
                System.out.print("say" + "\t");
            }
            if (sen[i].contains("ayudar")) {
                System.out.print("help" + "\t");
            }
            if (sen[i].contains("linea")) {
                System.out.print("line" + "\t");
            }
            if (sen[i].contains("causa")) {
                System.out.print("cause" + "\t");
            }
            if (sen[i].contains("mucho")) {
                System.out.print("much" + "\t");
            }
            if (sen[i].contains("traer")) {
                System.out.println("bring" + "\t");
            }
            if (sen[i].contains("tarea")) {
                System.out.print("homework" + "\t");
            }
            if (sen[i].contains("clase")) {
                System.out.print("class" + "\t");
            }
            if (sen[i].contains(" hoy ")) {
                System.out.print("today" + "\t");
            }
            if(sen[i].contains("emos") || sen[i].contains("imos") || sen[i].contains("amos")){
                System.out.print("we" + "\t");
            }
            if (sen[i].contains("escuela")) {
                System.out.println("school" + "\t");
            }
        }
    }
}
